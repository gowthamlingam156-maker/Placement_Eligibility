"""PlacementPulse - run with:  python app.py   then open http://127.0.0.1:5000"""
from flask import Flask, jsonify, render_template, request

from engine.eligibility import check_all
from engine.planner import build_plan
from engine.skillgap import compare, load_skills

app = Flask(__name__)

SAMPLE_RESUME = ("Skills: Python, Java, HTML, CSS, SQL, Flask, GitHub. "
                 "Projects: Diabetes retina detection using TensorFlow and CNN with a Flask web app.")
SAMPLE_JD = ("We need a Software Engineer with strong Java, SQL and data structures and algorithms. "
             "Knowledge of Spring, REST APIs, Docker, AWS and Agile. Good communication and teamwork. "
             "Java and SQL are mandatory.")


def _num(form, name, default=0.0, lo=0.0, hi=100.0):
    try:
        value = float(form.get(name, default))
    except (TypeError, ValueError):
        value = default
    return max(lo, min(hi, value))


def analyze(data):
    profile = {
        "tenth": _num(data, "tenth"), "twelfth": _num(data, "twelfth"), "ug": _num(data, "ug"),
        "standing_arrears": int(_num(data, "standing_arrears", 0, 0, 50)),
        "history_arrears": int(_num(data, "history_arrears", 0, 0, 50)),
    }
    days = int(_num(data, "days", 14, 1, 90))
    gap = compare(data.get("resume", ""), data.get("jd", ""))
    skills = load_skills()
    return {
        "profile": profile,
        "eligibility": check_all(profile),
        "gap": gap,
        "plan": build_plan(gap["missing"], days, skills),
        "days": days,
        "skills": skills,
    }


@app.get("/")
def index():
    demo = request.args.get("demo") == "1"
    form = {"tenth": 85, "twelfth": 80, "ug": 72, "standing_arrears": 0, "history_arrears": 2,
            "days": 14, "resume": SAMPLE_RESUME, "jd": SAMPLE_JD} if demo else {"days": 14}
    return render_template("index.html", form=form, result=None)


@app.post("/")
def analyze_form():
    return render_template("index.html", form=request.form, result=analyze(request.form))


@app.post("/api/analyze")
def analyze_api():
    result = analyze(request.get_json(silent=True) or {})
    result.pop("skills")
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)
