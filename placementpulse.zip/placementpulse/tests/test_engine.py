import unittest

from engine.eligibility import check_company
from engine.planner import build_plan
from engine.skillgap import compare, extract_skills

RULE = {"name": "X", "min_tenth": 60, "min_twelfth": 60, "min_ug": 60,
        "max_standing_arrears": 0, "max_history_arrears": 2}


def profile(**kw):
    base = {"tenth": 80, "twelfth": 80, "ug": 75, "standing_arrears": 0, "history_arrears": 0}
    base.update(kw)
    return base


class EligibilityTests(unittest.TestCase):
    def test_eligible(self):
        self.assertEqual(check_company(profile(), RULE)["status"], "eligible")

    def test_low_percentage_fails(self):
        r = check_company(profile(ug=55), RULE)
        self.assertEqual(r["status"], "not_eligible")
        self.assertIn("UG", r["reasons"][0])

    def test_standing_arrear_fails(self):
        self.assertEqual(check_company(profile(standing_arrears=1), RULE)["status"], "not_eligible")

    def test_history_limit(self):
        self.assertEqual(check_company(profile(history_arrears=3), RULE)["status"], "not_eligible")

    def test_borderline_is_at_risk(self):
        self.assertEqual(check_company(profile(ug=61), RULE)["status"], "at_risk")


class SkillTests(unittest.TestCase):
    def test_java_not_matched_inside_javascript(self):
        self.assertNotIn("java", extract_skills("I know JavaScript"))

    def test_cpp_detected(self):
        self.assertIn("c++", extract_skills("Strong in C++ and STL"))

    def test_score(self):
        r = compare("Python SQL", "Python SQL Docker")
        self.assertEqual(r["missing"], ["docker"])
        self.assertEqual(r["score"], 67)

    def test_empty_jd(self):
        self.assertTrue(compare("Python", "no skills here")["jd_empty"])


class PlannerTests(unittest.TestCase):
    def test_plan_fits_days(self):
        out = build_plan(["dsa", "docker"], total_days=5)
        self.assertEqual(out["days_used"], 5)
        self.assertEqual(out["skipped"], ["docker"])

    def test_last_day_is_practice(self):
        out = build_plan(["git"], total_days=3)
        self.assertTrue(out["plan"][-1]["task"].startswith("Practice"))


if __name__ == "__main__":
    unittest.main()
