"""Rule-based placement eligibility checker.

Rules live in data/companies.json so you can edit them without touching code.
"""
import json
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data" / "companies.json"
BORDERLINE_MARGIN = 3.0  # percent points


def load_companies(path=DATA):
    with open(path, encoding="utf-8") as f:
        return json.load(f)["companies"]


def check_company(profile, company):
    """Return dict: status in {eligible, at_risk, not_eligible} plus reasons."""
    reasons, risks = [], []

    for key, label in (("tenth", "10th"), ("twelfth", "12th"), ("ug", "UG")):
        have, need = profile[key], company[f"min_{key}"]
        if have < need:
            reasons.append(f"{label} is {have}% but {need}% is required (short by {need - have:.1f}).")
        elif have - need < BORDERLINE_MARGIN:
            risks.append(f"{label} is only {have - need:.1f} points above the {need}% cutoff.")

    standing, history = profile["standing_arrears"], profile["history_arrears"]
    if standing > company["max_standing_arrears"]:
        reasons.append(f"{standing} standing arrear(s); limit is {company['max_standing_arrears']}.")
    max_hist = company["max_history_arrears"]
    if max_hist is not None and history > max_hist:
        reasons.append(f"{history} cleared arrear(s); limit is {max_hist}.")
    elif history > 0 and max_hist is None:
        risks.append("History of arrears is allowed, but clear any standing ones early.")

    status = "not_eligible" if reasons else ("at_risk" if risks else "eligible")
    return {"company": company["name"], "status": status, "reasons": reasons,
            "risks": risks, "verified": company.get("verified", False)}


def check_all(profile, companies=None):
    companies = companies or load_companies()
    order = {"eligible": 0, "at_risk": 1, "not_eligible": 2}
    return sorted((check_company(profile, c) for c in companies), key=lambda r: order[r["status"]])
