"""Turn missing skills into a day-by-day study plan that fits your available days."""
from .skillgap import load_skills


def build_plan(missing, total_days, skills=None):
    skills = skills or load_skills()
    plan, day = [], 1
    for key in missing:
        info = skills.get(key)
        if not info:
            continue
        left = total_days - day + 1
        if left <= 0:
            break
        days_for = min(info["days"], left)
        topics = info["topics"]
        for i in range(days_for):
            # last allotted day is always hands-on practice
            if i == days_for - 1:
                task = "Practice: " + info["practice"]
            else:
                task = "Learn: " + topics[min(i, len(topics) - 1)]
            plan.append({"day": day, "skill": key, "category": info["category"], "task": task})
            day += 1
    done = {p["skill"] for p in plan}
    skipped = [k for k in missing if k in skills and k not in done]
    return {"plan": plan, "skipped": skipped, "days_used": day - 1}
