"""Compare a resume against a job description using an editable skill map."""
import json
import re
from collections import Counter
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data" / "skills.json"


def load_skills(path=DATA):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _pattern(alias):
    # Custom boundaries so "c++" and "node.js" match but "java" does not match "javascript".
    return re.compile(r"(?<![A-Za-z0-9+#])" + re.escape(alias) + r"(?![A-Za-z0-9+#])", re.I)


def extract_skills(text, skills=None):
    """Return Counter {skill_key: mention_count}."""
    skills = skills or load_skills()
    found = Counter()
    for key, info in skills.items():
        for alias in info["aliases"]:
            hits = len(_pattern(alias).findall(text or ""))
            if hits:
                found[key] += hits
    return found


def compare(resume_text, jd_text, skills=None):
    skills = skills or load_skills()
    resume = extract_skills(resume_text, skills)
    jd = extract_skills(jd_text, skills)
    if not jd:
        return {"score": 0, "matched": [], "missing": [], "extra": sorted(resume), "weights": {}, "jd_empty": True}

    weight = {k: min(v, 3) for k, v in jd.items()}  # repeated mentions matter, but capped
    total = sum(weight.values())
    matched = sorted((k for k in jd if k in resume), key=lambda k: -weight[k])
    missing = sorted((k for k in jd if k not in resume), key=lambda k: -weight[k])
    score = round(100 * sum(weight[k] for k in matched) / total)
    extra = sorted(k for k in resume if k not in jd)
    return {"score": score, "matched": matched, "missing": missing, "extra": extra,
            "weights": weight, "jd_empty": False}
